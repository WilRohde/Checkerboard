from flask import Flask, render_template  # Import Flask to allow us to create our app
app = Flask(__name__)    # Create a new instance of the Flask class called "app"
@app.route('/')          # The "@" decorator associates this route with the function immediately following
def board(rows = 8, columns = 8):
    return render_template('index.html',ranks=rows,files=columns)  # Return the string 'Hello World!' as a response

@app.route('/<int:rows>')
def board_rows(rows,columns = 8):
    return render_template('index.html',ranks=rows,files=columns)

@app.route('/<int:rows>/<int:columns>')
def board_rows_and_columns(rows,columns):
    return render_template('index.html',ranks=rows,files=columns)

@app.route('/<int:rows>/<int:columns>/<string:color_one>/<string:color_two>')
def board_colors(rows,columns,color_one,color_two):
    return render_template('index.html',ranks=rows,files=columns,colorone=color_one,colortwo=color_two)

if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)    # Run the app in debug mode.
